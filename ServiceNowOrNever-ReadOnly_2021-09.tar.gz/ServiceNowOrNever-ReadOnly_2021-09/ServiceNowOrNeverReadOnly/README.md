# ServiceNowOrNever : SNOW ON

This project will have a Java microservice that 
   reads/writes from/to webservices at developer.servicenow.com :

Java microservice gets the SNOW requests , 
   launches python scripts and
      afterwards updates the changes . . .

https://www.youtube.com/watch?v=ngVxiJ78t3Q
