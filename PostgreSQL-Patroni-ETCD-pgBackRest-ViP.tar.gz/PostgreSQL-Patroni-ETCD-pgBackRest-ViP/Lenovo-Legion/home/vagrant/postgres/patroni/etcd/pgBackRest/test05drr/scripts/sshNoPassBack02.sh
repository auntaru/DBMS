set -x
#ssh root@192.168.12.121 "/vagrant/scripts/rootSSHnoPass.sh"
#ssh root@192.168.12.122 "/vagrant/scripts/rootSSHnoPass.sh"
#ssh root@192.168.12.123 "/vagrant/scripts/rootSSHnoPass.sh"
#ssh root@192.168.12.121 "etcdctl member list -w table"
#ssh root@192.168.12.122 "etcdctl endpoint health --cluster -w table"
#ssh root@192.168.12.123 "patronictl -c /etc/patroni/patroni.yml list postgres"

#sshpass -p 'patroni' ssh postgres@192.168.12.121 "/vagrant/scripts/pgSSHnoPsswd.sh"
#sshpass -p 'patroni' ssh postgres@192.168.12.122 "/vagrant/scripts/pgSSHnoPsswd.sh"
#sshpass -p 'patroni' ssh postgres@192.168.12.123 "/vagrant/scripts/pgSSHnoPsswd.sh"


ssh-keyscan -H 192.168.12.121 >> ~/.ssh/known_hosts
ssh-keyscan -H 192.168.12.122 >> ~/.ssh/known_hosts
ssh-keyscan -H 192.168.12.123 >> ~/.ssh/known_hosts

sshpass -p 'patroni' ssh postgres@192.168.12.121 "/vagrant/scripts/userSSHnoPass06.sh"
sshpass -p 'patroni' ssh postgres@192.168.12.122 "/vagrant/scripts/userSSHnoPass06.sh"
sshpass -p 'patroni' ssh postgres@192.168.12.123 "/vagrant/scripts/userSSHnoPass06.sh"


#ssh root@192.168.12.121 "/vagrant/scripts/pgSSHnoPass.sh"
#ssh root@192.168.12.122 "/vagrant/scripts/pgSSHnoPass.sh"
#ssh root@192.168.12.123 "/vagrant/scripts/pgSSHnoPass.sh"

