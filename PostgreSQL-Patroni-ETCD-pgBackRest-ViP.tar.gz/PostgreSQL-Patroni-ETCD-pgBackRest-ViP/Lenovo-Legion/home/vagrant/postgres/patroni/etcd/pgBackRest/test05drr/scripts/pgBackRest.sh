#!/usr/bin/env bash
set -x

# sudo usermod -aG wheel postgres
sudo echo -e "patroni\npatroni" | passwd postgres

cat <<EOF > /etc/pgbackrest.conf
[main]
pg1-path=/data/patroni
pg1-port=5432
pg1-host=192.168.12.121
pg1-socket-path=/run/postgresql
pg2-path=/data/patroni
pg2-port=5432
pg2-host=192.168.12.122
pg2-socket-path=/data/patroni
pg3-path=/data/patroni
pg3-port=5432
pg3-host=192.168.12.123
pg3-socket-path=/data/patroni

[global]
repo1-path=/var/lib/pgbackrest
repo1-retention-full=4
start-fast=y
EOF

su -c "pgbackrest --stanza=main --log-level-console=info stanza-create" postgres
su -c "pgbackrest --stanza=main --log-level-console=info backup" postgres
