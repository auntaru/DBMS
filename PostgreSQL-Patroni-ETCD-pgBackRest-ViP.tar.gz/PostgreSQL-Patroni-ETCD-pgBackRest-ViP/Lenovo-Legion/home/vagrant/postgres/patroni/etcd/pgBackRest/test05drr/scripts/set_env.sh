#!/usr/bin/env sh
set -x
# echo "192.168.83.19 olx83ora19c olx83ora19c.localdomain" >> /etc/hosts
# sudo echo -e "oracle\noracle" | passwd oracle

timedatectl list-timezones | grep -i "Paris"
timedatectl set-timezone "Europe/Bucharest"
mkdir -p /home/ha/scripts
cat > /home/ha/scripts/setEnv.sh <<EOF1
#umask 022
export HA_BASE=/home/ha/scripts
export PGBACKREST_HOME=/home/pgbackrest
export POSTGRES_HOME=/home/postgres
export PS1="[\u@\h \T \w]$ "
PATH=\$PATH:\$HA_BASE
export PATH
EOF1

# echo ". /home/ha/scripts/setEnv.sh" >> /home/pgbackrest/.bash_profile
# echo ". /home/ha/scripts/setEnv.sh" >> /home/postgres/.bash_profile
chmod 777 /home/ha/scripts/setEnv.sh

#cat > /usr/lib/systemd/system/ORCLCDB@lsnrctl.service <<EOF3
#[Unit]
#Description=Oracle Net Listener
#After=network.target
#[Service]
#Type=forking
#EnvironmentFile=/etc/sysconfig/ORCLCDB.oracledb
#ExecStart=/opt/oracle/product/19c/dbhome_1/bin/lsnrctl start
#ExecStop=/opt/oracle/product/19c/dbhome_1/bin/lsnrctl stop
#User=oracle
#[Install]
#WantedBy=multi-user.target
#EOF3

#cat > /usr/lib/systemd/system/ORCLCDB@oracledb.service <<EOF4
#configure database service
#[Unit]
#Description=Oracle Database service
#After=network.target lsnrctl.service
#[Service]
#Type=forking
#EnvironmentFile=/etc/sysconfig/ORCLCDB.oracledb
#ExecStart=/opt/oracle/product/19c/dbhome_1/bin/dbstart \$ORACLE_HOME
#ExecStop=/opt/oracle/product/19c/dbhome_1/bin/dbshut \$ORACLE_HOME
#User=oracle
#[Install]
#WantedBy=multi-user.target
#EOF4

# systemctl daemon-reload
# systemctl enable ORCLCDB@lsnrctl ORCLCDB@oracledb
