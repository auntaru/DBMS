#!/usr/bin/env sh
set -x
yum install -y oracle-database-preinstall-19c mc
yum -y localinstall /tmp/oracle-database-ee-19c-1.0-1.x86_64.rpm
echo "192.168.83.19 olx83ora19c olx83ora19c.localdomain" >> /etc/hosts
sudo echo -e "oracle\noracle" | passwd oracle
mkdir -p /home/oracle/scripts
cat > /home/oracle/scripts/setEnv.sh <<EOF1
umask 022
export ORACLE_SID=ORCLCDB
export ORACLE_BASE=/opt/oracle/oradata
export ORACLE_HOME=/opt/oracle/product/19c/dbhome_1
PATH=\$PATH:\$ORACLE_HOME/bin
export PATH
EOF1

echo ". /home/oracle/scripts/setEnv.sh" >> /home/oracle/.bash_profile
/etc/init.d/oracledb_ORCLCDB-19c configure
# /etc/init.d/oracledb_ORCLCDB-19c start

# sqlplus / as sysdba
# show pdbs
# select instance_name, host_name, version, startup_time from v$instance; 


cp /etc/oratab /etc/ini.oratab.old
echo "ORCLCDB:/opt/oracle/product/19c/dbhome_1:Y" > /etc/oratab


cat > /etc/sysconfig/ORCLCDB.oracledb <<EOF2
# create new : define environment variables
ORACLE_BASE=/opt/oracle/oradata
ORACLE_HOME=/opt/oracle/product/19c/dbhome_1
ORACLE_SID=ORCLCDB
EOF2

cat > /usr/lib/systemd/system/ORCLCDB@lsnrctl.service <<EOF3
# configure listener service
[Unit]
Description=Oracle Net Listener
After=network.target
[Service]
Type=forking
EnvironmentFile=/etc/sysconfig/ORCLCDB.oracledb
ExecStart=/opt/oracle/product/19c/dbhome_1/bin/lsnrctl start
ExecStop=/opt/oracle/product/19c/dbhome_1/bin/lsnrctl stop
User=oracle
[Install]
WantedBy=multi-user.target
EOF3

cat > /usr/lib/systemd/system/ORCLCDB@oracledb.service <<EOF4
# configure database service
[Unit]
Description=Oracle Database service
After=network.target lsnrctl.service
[Service]
Type=forking
EnvironmentFile=/etc/sysconfig/ORCLCDB.oracledb
ExecStart=/opt/oracle/product/19c/dbhome_1/bin/dbstart \$ORACLE_HOME
ExecStop=/opt/oracle/product/19c/dbhome_1/bin/dbshut \$ORACLE_HOME
User=oracle
[Install]
WantedBy=multi-user.target
EOF4

# systemctl daemon-reload
# systemctl enable ORCLCDB@lsnrctl ORCLCDB@oracledb
#
# Oracle Database 19c : Install from RPM Package
# https://www.server-world.info/en/note?os=CentOS_8&p=oracle19c&f=6

