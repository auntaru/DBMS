#!/usr/bin/env bash
#yum clean all && yum update -y
set -x
yum -y install epel-release && yum -y install bash-completion git net-tools bind-utils wget telnet vim expect gcc-c++ make jq mc unzip nfs-utils sshpass curl policycoreutils-python openssh-server
# https://www.cybertec-postgresql.com/en/postgresql-clustering-vip-manager/
yum -y install https://github.com/cybertec-postgresql/vip-manager/releases/download/v1.0.1/vip-manager_1.0.1-1_amd64.rpm
sed -i.bak -e 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config
sed -i.bak -e 's/SELINUX=enforcing/SELINUX=disabled/' /etc/selinux/config
sed -i.bak -e 's/keepcache=0/keepcache=1/' /etc/yum.conf
echo "LogLevel DEBUG3" >> /etc/ssh/sshd_config
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
echo "StrictModes no ">> /etc/ssh/sshd_config

systemctl restart sshd
systemctl stop firewalld && sudo systemctl disable firewalld

if [ "$(hostname)" = "pg01" -o "$(hostname)" = "pg02" -o "$(hostname)" = "pg03" ]
then
cat <<EOF > /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.12.121 pg01
192.168.12.122 pg02
192.168.12.123 pg03
EOF
fi
# in hosts there are iPs for sshNoPass
cat <<EOF > /home/hosts
192.168.12.121
192.168.12.122
192.168.12.123
192.168.12.233
EOF

cat <<EOF > /home/pghosts
192.168.12.121
192.168.12.122
192.168.12.123
EOF


cat <<EOF > /home/pgbackresthost
192.168.12.233
EOF

# sed -n '/^#/!p' /etc/ssh/sshd_config
# sed -i 's/^PasswordAuthentication.*/PasswordAuthentication yes/' /etc/ssh/sshd_config
# systemctl restart sshd.service
