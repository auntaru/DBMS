#!/bin/bash -x
#
name="AUN-ALEX-AVU"
existing_table="test_avu_210404"
existing_database="avu"
last_update="2021-04-04"
existing_user=$USER
POSTGRES_PORT=$PGPORT
cd ~
LoG="dbLoG.txt"

#
psql -U $existing_user -p $POSTGRES_PORT -d $existing_database -c "CREATE TABLE IF NOT EXISTS $existing_table ( id SERIAL PRIMARY KEY, name VARCHAR(255) NOT NULL, last_update DATE , created_at TIMESTAMPTZ DE                           FAULT Now() )"
#
echo "List aLL available databases the instance at PORT $POSTGRES_PORT by connecting to postgres default datatabase : " > $LoG
psql -U $existing_user   -p $POSTGRES_PORT  -d postgres           -c "\l+" >> $LoG
#
echo "Schemas in the existing database = $existing_database : " >> $LoG
psql -U $existing_user   -p $POSTGRES_PORT  -d $existing_database -c "\dn+" >> $LoG
#
echo "Tables in the existing database = $existing_database : " >> $LoG
psql -U $existing_user   -p $POSTGRES_PORT  -d $existing_database -xc "\dt+" >> $LoG
#
echo "Display structure of the existing_table = $existing_table in the existing database = $existing_database : " >> $LoG
psql -U $existing_user -p $POSTGRES_PORT -d $existing_database -c "\d+ $existing_table" >> $LoG
#
i=0
# echo "infinite loops [ hit CTRL+C to stop]"
for (( ; ; ))
do
   echo "infinite loops [ hit CTRL+C to stop]"
   i=$((i+1))
   echo $i " - records inserted "
   psql -U $existing_user    -p $POSTGRES_PORT -d $existing_database -c " insert into dbo.$existing_table ( name, last_update ) values ( '$name' , '$last_update' );"
   # psql -U $existing_user    -p $POSTGRES_PORT -d $existing_database -xc " SELECT now() ;"
   echo " TotaL Records in the existing_table = $existing_table of the existing database = $existing_database : "
   psql -U $existing_user    -p $POSTGRES_PORT -d $existing_database -xc " select now() , count(*) from dbo.$existing_table ;"
   echo " The Records with min(created_at) & max(created_at) : "
   psql -U $USER -p $PGPORT -d pgdlpf64004 -xc "select min(created_at) , max(created_at) from dbo.$existing_table"

done
cd -
# EOFSQL
