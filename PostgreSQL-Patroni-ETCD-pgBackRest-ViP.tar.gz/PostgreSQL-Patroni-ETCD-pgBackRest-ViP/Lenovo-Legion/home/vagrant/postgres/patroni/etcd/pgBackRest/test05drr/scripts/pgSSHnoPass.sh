#!/bin/bash
#
# Setup Passwordless SSH Login for Multiple Remote Servers Using Script
# https://www.tecmint.com/passwordless-ssh-login-for-multiple-remote-servers/
#
# to be run as user postgres
# checks HOST_FILE and as vagrant user is copying id_rsa into iPs from hosts file
# afterwards , ssh without pass into iPs from hosts file
# updated.avu@2021-04.18
# 
# parametres : #1 = hostsfile
#              #2 = user
# 
set -x

pgPath="/var/lib/pgsql"
ID_RSA=$pgPath/.ssh/id_rsa
#ID_RSA="~/.ssh/id_rsa"
#ID_RSA="/root/.ssh/id_rsa"

#if id "$1" &>/dev/null; then
#    echo 'user found'
#else
#    echo 'user not found'
#fi

if id "postgres" &>/dev/null; then
    echo 'postgres user found'
    # sudo usermod -aG wheel postgres
else
    echo 'postgres user not found'
    # adduser -G wheel postgres -m -d $pgPath -s /bin/bash
fi

sudo echo -e "patroni\npatroni" | passwd postgres

if [[ ! -f $ID_RSA ]]
then
    echo "File $ID_RSA not found !"
    # echo 'generate one with this command : ssh-keygen -b 2048 -t rsa -f ~/.ssh/id_rsa -q -N ""'
    # exit 2
fi

# automated answer - yes - to create with overwrite
rm -rf $ID_RSA
su -c "ssh-keygen -b 4096 -t rsa -f $ID_RSA -q -N '' " postgres
# ssh-keygen -b 2048 -t rsa -f $ID_RSA -q -N '' <<< ""$'\n'"y" 2>&1 >/dev/null

current_user=$(whoami)
USER_NAME="postgres"
DEFAULT_HOST_FILE="/home/hosts"
HOST_FILE=$1
ERROR_FILE="/tmp/ssh-copy_error.txt"

if test -z "$HOST_FILE"
then
      echo "\$HOST_FILE is empty !"
      HOST_FILE=$DEFAULT_HOST_FILE
      echo "\$HOST_FILE set by default to '$HOST_FILE'!"
else
      echo "\$HOST_FILE is NOT empty"
fi

if [ ! -f $HOST_FILE ]; then
        echo "host file $HOST_FILE - received as parameter - not found !"
        echo "127.0.0.1" > $HOST_FILE
        echo "$HOST_FILE created with 127.0.0.1"
fi

if [ -z "$PUBLIC_KEY_FILE" ]
then
      echo "\$PUBLIC_KEY_FILE is empty"
else
      echo "\$PUBLIC_KEY_FILE is NOT empty"
fi
echo $PUBLIC_KEY_FILE
#PUBLIC_KEY_FILE="$2"
#if [ ! -f  $PUBLIC_KEY_FILE ]; then
#        echo "File '$PUBLIC_KEY_FILE' not found!"
#        exit 1
#fi

for IP in `cat $HOST_FILE`; do
        # here , I stiLL need - manually - to ssh interactively between the two hosts to accept prompt for defaults
        su -c "ssh-keyscan -H $IP >> ~/.ssh/known_hosts " postgres
        #su -c "sshpass -p 'patroni' ssh-copy-id -i $PUBLIC_KEY_FILE $USER_NAME@$IP 2>$ERROR_FILE" postgres
        su -c "sshpass -p 'patroni' ssh-copy-id -i $USER_NAME@$IP " postgres
        RESULT=$?
        if [ $RESULT -eq 6 ]; then
                echo ""
                echo "Warning : public key copied to $IP wit exit code 6 from sshpass"
                echo ""
        elif [ $RESULT -eq 0 ]; then
                echo ""
                echo "Public key successfully copied to $IP"
                echo ""
        else
                echo "$(cat  $ERROR_FILE)"
                echo
                exit 3
        fi
        echo ""
done

