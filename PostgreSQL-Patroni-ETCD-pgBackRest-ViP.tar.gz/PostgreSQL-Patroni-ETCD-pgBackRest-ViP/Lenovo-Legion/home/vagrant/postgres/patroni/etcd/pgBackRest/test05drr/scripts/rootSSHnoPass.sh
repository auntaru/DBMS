#!/bin/bash
#
# Setup Passwordless SSH Login for Multiple Remote Servers Using Script
# https://www.tecmint.com/passwordless-ssh-login-for-multiple-remote-servers/
#
# to be run as user postgres
# checks HOST_FILE and as vagrant user is copying id_rsa into iPs from hosts file
# afterwards , ssh without pass into iPs from hosts file
# updated.avu@2021-04.18
# 
# parametres : #1 = hostsfile
#              #2 = user
# 
set -x

#ID_RSA="~/.ssh/id_rsa"
ID_RSA="/root/.ssh/id_rsa"

#if id "$1" &>/dev/null; then
#    echo 'user found'
#else
#    echo 'user not found'
#fi

if [[ ! -f $ID_RSA ]]
then
    echo "File $ID_RSA not found !"
    # echo 'generate one with this command : ssh-keygen -b 2048 -t rsa -f ~/.ssh/id_rsa -q -N ""'
    # exit 2
fi

# automated answer - yes - to create with overwrite
# rm -rf $ID_RSA
ssh-keygen -b 4096 -t rsa -f $ID_RSA -q -N ''

current_user=$(whoami)
USER_NAME="root"
USER_PASS="vagrant"
DEFAULT_HOST_FILE="/home/hosts"
HOST_FILE=$1
ERROR_FILE="/tmp/ssh-copy_error.txt"

if test -z "$HOST_FILE"
then
      echo "\$HOST_FILE is empty !"
      HOST_FILE=$DEFAULT_HOST_FILE
      echo "\$HOST_FILE set by default to '$HOST_FILE'!"
else
      echo "\$HOST_FILE is NOT empty"
fi

if [ ! -f $HOST_FILE ]; then
        echo "host file $HOST_FILE - received as parameter - not found !"
        echo "127.0.0.1" > $HOST_FILE
        echo "$HOST_FILE created with 127.0.0.1"
fi

for IP in `cat $HOST_FILE`; do
        # here , I stiLL need - manually - to ssh interactively between the two hosts to accept prompt for defaults
        ssh-keyscan -H $IP >> ~/.ssh/known_hosts
        sshpass -p $USER_PASS ssh-copy-id -i $USER_NAME@$IP 2>$ERROR_FILE
        RESULT=$?
        if [ $RESULT -eq 6 ]; then
                echo ""
                echo "Warning : public key copied to $IP wit exit code 6 from sshpass"
                echo ""
        elif [ $RESULT -eq 0 ]; then
                echo ""
                echo "Public key successfully copied to $IP"
                echo ""
        else
                echo "$(cat  $ERROR_FILE)"
                echo
                exit 3
        fi
        sshpass -p $USER_PASS ssh -t $USER_NAME@$IP '/sbin/restorecon -Rv ~/.ssh' "
        ssh $REMOTE_NAME@$IP 'hostname; whoami; pwd' "
        echo ""
done

