#!/usr/bin/env bash
set -x

# sudo usermod -aG wheel postgres
sudo echo -e "patroni\npatroni" | passwd postgres

# https://www.migops.com/blog/2021/04/09/pgbackrest-the-best-postgres-backup-tool-with-a-very-active-community/
# sudo groupadd pgbackrest
# sudo useradd -r -g pgbackrest pgbackrest
# sudo mkdir -p /home/pgbackrest
# sudo chown pgbackrest:pgbackrest /home/pgbackrest
# sudo echo -e "patroni\npatroni" | passwd pgbackrest
# sudo mkdir -p /var/log/pgbackrest
# sudo chown -R pgbackrest:pgbackrest /var/log/pgbackrest
# sudo chmod -R 700 /var/log/pgbackrest
# https://www.migops.com/blog/2021/04/09/pgbackrest-the-best-postgres-backup-tool-with-a-very-active-community/

cat <<EOF > /etc/pgbackrest.conf
[main]
pg1-path=/data/patroni
pg1-port=5432
pg1-host=192.168.12.121
pg1-socket-path=/run/postgresql
pg1-user=postgres
pg2-path=/data/patroni
pg2-port=5432
pg2-host=192.168.12.122
pg2-socket-path=/run/postgresql
pg2-user=postgres
pg3-path=/data/patroni
pg3-port=5432
pg3-host=192.168.12.123
pg3-socket-path=/run/postgresql
pg3-user=postgres

[global]
repo1-path=/home/pgbackrest
repo1-retention-full=4
start-fast=y
EOF

su -c "pgbackrest --stanza=main --log-level-console=info stanza-create" pgbackrest
su -c "pgbackrest --stanza=main --log-level-console=info backup" pgbackrest
