# ansibleDevOps

git clone https://github.com/auntaru/ansibleDevOps.git
git status
git add Vagrantfile maria.yml
git commit -m "MariaDB CentOS Vagrant KVM Ansible"
git push -u origin master
git add virtualbox/*
git status
git commit -m "MariaDB Ubuntu Vagrant Virtualbox Ansible"
git push -u origin master

https://product.hubspot.com/blog/git-and-github-tutorial-for-beginners


root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps# pwd
/home/ansible/vagrant/KVM-libvirt/ansibleDevOps
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps#
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps#
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps# ls -lastrh
total 68K
4,0K -rw-r--r-- 1 alex sudo  775 aug 30 19:07 Vagrantfile
4,0K -rw-r--r-- 1 alex sudo 1,8K aug 30 21:54 maria.yml
4,0K -rw-r--r-- 1 root root   15 aug 30 22:40 README.md
 36K -rw-r--r-- 1 root root  35K aug 30 22:40 LICENSE
4,0K drwxr-xr-x 4 alex sudo 4,0K aug 30 22:41 ..
4,0K drwxr-xr-x 2 root root 4,0K aug 30 22:45 virtualbox
4,0K drwxr-xr-x 8 root root 4,0K aug 30 22:47 .git
4,0K drwxr-xr-x 3 root root 4,0K aug 30 23:01 .vagrant
4,0K drwxr-xr-x 5 root root 4,0K aug 30 23:01 .
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps#

root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps# cd virtualbox/
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps/virtualbox#
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps/virtualbox# ls -lastrh
total 16K
4,0K -rw-r--r-- 1 alex sudo  743 aug 29 22:25 Vagrantfile
4,0K -rw-r--r-- 1 alex sudo 1,7K aug 29 22:33 maria.yml
4,0K drwxr-xr-x 2 root root 4,0K aug 30 22:45 .
4,0K drwxr-xr-x 5 root root 4,0K aug 30 23:01 ..
root@Lenovo-Legion:/home/ansible/vagrant/KVM-libvirt/ansibleDevOps/virtualbox#
